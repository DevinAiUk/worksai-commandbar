# WorksAi CommandBar CLI (v1.2.0)

Install globally with `npm install -g ./worksai-commandbar-1.2.0.tgz` or run `node package/bin/worksai-commandbar.mjs "128 * 4 + 256"`.
